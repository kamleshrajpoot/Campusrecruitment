
<!DOCTYPE html>
<html>
    <head> 
         <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.1.1.min.js"></script>
    </head>
     <style>
    div.row
        {
            background-color:burlywood;
        }
        ul li a{
            color:blueviolet;
        }
        div container d1 h1{
            text-align:center;
        }
</style>
    <body>
        
   <div class="row">
                            <div class="col-md-4">
                              
						
					
                                    <h3 class="title">About Us</h3>
                                
                                <nav>
                                  Campus Recruitment System of NIT Agartala, is the student run organization which handles all activities related to the campus placement of the graduating batch.
                                </nav>
                        </div>
                
						
                       <div  class="col-md-4">
                                    <!-- Title -->
                                    <h3 class="title">Quick Link</h3>
                                
                                
                                    <!-- Text -->
                                     <nav>
                                    <ul>
                                        <!-- List Items -->
										<li><a href="http://www.nita.ac.in"> NITA Home Page</a></li>
                                        <li><a href="http://www.nita.ac.in/NITAmain/adminstration/adminstrationhome.html">Adminstration Home</a></li>
                                        <li><a href="http://www.nita.ac.in/NITAmain/departments/departmentshome.html">Departments Home</a></li>
                                        <li><a href="http://www.nita.ac.in/NITAmain/academics/academicshome.html">Academics Home</a></li>
                                        <li><a href="http://www.nita.ac.in/NITAmain/students/studentsHome.html">Students Home</a></li>
                                    </ul>
                                </nav>
                                <!-- Count -->
                                <!-- Social Links -->
                                
                            </div>
       
                            <div  class="col-md-4">
                        
                                    <!-- Title -->
                                    <h3 class="title">Contact Us</h3>
                                
                                <!-- Text -->
                               
                                <!-- Address -->
                                <p><strong>Address:</strong><br> NIT Agartala,<br> West Tripura barjala jirania  (465697).</p>
                                <!-- Phone -->
								<p><strong>Phone :</strong>011  313030
                                <p><strong>Mobile :</strong> 9713254069
                                   
                                </p>
								 <p><strong>Email :</strong>  nita@gmail.com
                                   
                                </p>
                            </div>
						 </div>
						
                        

        
        <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.1.1.min.js"></script>
     </body
     
</html>

