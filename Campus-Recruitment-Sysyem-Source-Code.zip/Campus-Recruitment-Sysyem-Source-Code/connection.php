<?php

 $con=mysqli_connect('localhost','root','','campus_placement') or die();

?>