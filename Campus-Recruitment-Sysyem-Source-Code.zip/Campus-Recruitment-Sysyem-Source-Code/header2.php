     
            <div class="panel panel-default">
  
  <div class="panel-body">
      <div>  <img src="campus88.jpg" class="img-responsive" alt="Responsive image"></div>
            </div>
                
            
            </div>
   
            <div class="row">
            <div class="jumbutron">
                   <div class="col-md-12">
                   <ul class="nav nav-tabs">
                       <li role="presentation" class="info"><a href="index.php">Home</a></li>
                         <li role="presentation" class="dropdown">
    <a class=" dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
      For Students <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
                        <li role="presentation" class="btn btn-success"><a href="studentpolicy.php">Placement Policy</a></li>
                        <li role="presentation" class="btn btn-success"><a href="studentregistration.php"> For  Registration</a></li>
                        <li role="presentation" class="btn btn-success"><a href="studentlogin.php">For Student Login</a></li>
    </ul>
  </li>
                        <li role="presentation" class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" >
      For Companies <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
                        <li role="presentation" class="btn btn-success" ><a href="companypolicy.php">Procedure & Policy</a></li>
                        <li role="presentation" class="btn btn-success"><a href="companyregistration.php">For Registration</a></li>
                        <li role="presentation" class="btn btn-success"><a href="companylogin.php">For Company Login</a></li>
    </ul>
  </li>
                       <li role="presentation" class="info"><a href="#">Placement Statistics Of Recent Year</a> </li>
                        <li role="presentation" class="info"><a href="recruiters.php">Our Recruiters</a></li>
                        <li role="presentation" class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
      Contact Us <span class="caret"></span>
    </a>
                   <ul class="dropdown-menu">
                        <li role="presentation" class="btn btn-success"><a href="reachnita.php">Reach NIT Agartala</a></li>
                        <li role="presentation" class="btn btn-success"><a href="contacttpo.php"> Contact NITA TPO</a></li>
                    </ul>
                            </ul>
                   </div>
             </div>
            </div>