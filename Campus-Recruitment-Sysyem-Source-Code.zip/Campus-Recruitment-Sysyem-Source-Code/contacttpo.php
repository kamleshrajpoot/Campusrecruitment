<!DOCTYPE html>
    <html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="companylogin.js"></script>
        
     
    </head>
    <style>
        form{
            color:black;
        }
        button li a{
            text-decoration: none;
        
        }
      div.container
        {
            background-color:burlywood;
        }
        div container d1 h1{
            text-align: right;
        }
</style>
    <body> 
        
        <div  class="container">
              <br>
          
            <?php 
          
          include('header2.php');
          
          
          ?>
            <br>
      
<div class="row">
             
          <div class="col-md-12">
               <div class="container-fluid" >
                     <div class="jumbotron">
                       <div id="bodydesc" style="margin-left:auto; margin-right:auto;  overflow-y: scroll;">

                            <p id="desc" style="float:left;color: #666666; font-family: Candara,Trebuchet MS,sans-serif; font-size: 12px; font-weight: bold; border-right: thin dotted #666666; line-height: 18px;">  

        

  
                    <quite>  <h2 style=color:Green;>  Contact Us</h2> </quite>  
                           Chairman :	</br>
Prof. (Dr.) Umesh Mishra</br>
Phone: (0381) 2348518</br>
Email id:nita.tnp@gmail.com, tnp@nita.ac.in, ccdofficenita@gmail.com</br>
</br>
Faculty Coordinators:</br>

1.  Mr. Subhajit Deb, Assistant Professor, Civil Engineering Department</br>
Email: d_subhajitdeb@yahoo.co.in</br>
Phone: 9436138926</br>

2.  Dr. Pradeep Kumar Behera, Assistant Professor, School of Management</br>
Email: pradeepbhr@gmail.com</br>
Phone: 9572162903</br>

3.  Dr. Mriganka Sekhar Manna, Assistant Professor, Chemical Engineering Department.</br>
Email: mrigankamanna602@gmail.com</br>
Phone: 9089596361</br>

4.  Dr. Muthusivaramapandian M, Assistant Professor, Bio Engineering Department.</br>
Email: msrpmsiva@gmail.com</br>
Phone: 9856961669</br></br>

Office of the Centre for Career Development</br>

1.  Litan Sarkar, Junior Assistant.</br>
Email: litansarkar55@gmail.com</br>
Phone: 9612243164 .</br>
  

      </p>
           
              </div>

                     </div>
              </div>
         </div>
 </div>
                    <hr>
                     <?php include ("footer.php"); ?>
                    <hr>
    
        
         </div>
        
          <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="companylogin.js"></script>
        </body>
</html>