<!DOCTYPE html>
    <html>
    <head>
        <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="companylogin.js"></script>
        
     
    </head>
    <style>
        form{
            color:black;
        }
        button li a{
            text-decoration: none;
        
        }
      div.container
        {
            background-color:burlywood;
        }
        div container d1 h1{
            text-align: right;
        }
</style>
    <body> 
        
        <div  class="container">
              <br>
          
            <?php 
          
          include('header2.php');
          
          
          ?>
            <br>
      
<div class="row">
             
          <div class="col-md-12">
               <div class="container-fluid" >
                     <div class="jumbotron">
                         <h3 style=color:green;>Our Recruiters</h3>
                       <div class="row">
                           </br>
  <div class="col-xs-6 col-md-3">
    <a href="https://www.itcportal.com" class="thumbnail">
      <img src="itc.png" alt="itc">
    </a>
  </div>
<div class="col-xs-6 col-md-3">
    <a href="https://www.mahindra.com" class="thumbnail">
      <img src="mahindra.png" alt="mahindra">
    </a>
  </div>
                           <div class="col-xs-6 col-md-3">
    <a href="https://www.ril.com" class="thumbnail">
      <img src="reliance.png" alt="Adidas">
    </a>
  </div>
                           <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="volkswagns.jpg" alt="wangs">
    </a>
  </div>
                         </div>
                             <div class="row">
  <div class="col-xs-6 col-md-3">
    <a href="https://www.intel.in" class="thumbnail">
      <img src="intel.png" alt="Intel">
    </a>
  </div>
<div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="mig.png" alt="Adidas">
    </a>
  </div>
                           <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="cairn.png" alt="Adidas">
    </a>
  </div>
                           <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="Mastercard.jpg" alt="Adidas">
    </a>
  </div>
                           </div>
                                   <div class="row">
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="tata.png" alt="Adidas">
    </a>
  </div>
<div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="gofurt.png" alt="Adidas">
    </a>
  </div>
                           <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="mindtree.png" alt="Adidas">
    </a>
  </div>
                           <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="infosis.png" alt="Adidas">
    </a>
  </div>
                                        
</div> 

                     </div>
              </div>
         </div>
 </div>
                    <hr>
                     <?php include ("footer.php"); ?>
                    <hr>
    
        
         </div>
        
          <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.1.1.min.js"></script>
        <script type="text/javascript" src="companylogin.js"></script>
        </body>
</html>